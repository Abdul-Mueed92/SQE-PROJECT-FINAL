# Akaunting SQE Testing Report

## Test baseline

- Repository: `https://github.com/akaunting/akaunting.git`
- Commit: `3d893816338ea6b35ad8d62ac7899f9339dc16aa`
- Runtime: PHP 8.2 in an isolated Docker container
- Database: SQLite in-memory test database
- Date: 2026-11-19 (Asia/Karachi)

The uploaded `phpunit.xml`, request classes, and routes were compared with the
repository and are identical.

## Unit testing

Command:

```text
php artisan test --testsuite=Unit --log-junit=unit-all-results.xml
```

Result: **128 passed, 229 assertions, 0 failed**.

Added project-specific coverage:

- Invoice amount due: fully paid, zero total, unpaid, partial payment.
- Invoice status labels: paid, partial, sent, received, viewed, cancelled, draft.
- Invoice lifecycle: accrued and outstanding rules for eight statuses.
- Invoice payments: zero, partial, multiple, full, paid override, overpayment,
  zero payment, and two-decimal rounding.

## API and integration testing

Full feature suite result: **418 passed, 12 failed, 1,721 assertions**.

Focused API lifecycle suite result: **5 passed, 18 assertions, 0 failed**.

Verified API behavior:

- Missing credentials return `401 Unauthorized` and a `WWW-Authenticate` header.
- HTTP Basic authentication succeeds for the isolated test account.
- Authenticated ping succeeds.
- Invoice create, read, update, and delete lifecycle succeeds.
- Invalid invoice contact/category relations return `422 Unprocessable Entity`.
- ISO-dated income transaction creation succeeds.
- Job refusal returns `403 Forbidden`.
- Reconciled transfers cannot be updated or deleted through the API.
- Invalid transaction relations return `422`.
- Bill and invoice invalid-relation checks return `422`.
- Partial/full payments, overpayment prevention, taxes, discounts, and document
  status behavior pass their feature tests.

## Known environment-only failures

Twelve tests failed because the application deliberately uses
`email:rfc,dns`, while DNS lookup is unavailable inside the test container.
All failures report: `The email must be a valid email address.`

Affected areas:

- Users: 2
- Companies: 5
- Vendors: 2
- Customers: 3

These failures do not affect the invoice, bill, transaction, payment, transfer,
or focused API lifecycle suites. They should be rerun on a machine/container
with working DNS before final submission.

## Next stage

1. Rerun the 12 DNS-dependent tests in the local Windows environment.
2. Continue the remaining manual cases from `PAY-027`.
3. Run regression testing after manual testing is complete.
4. Perform basic security and performance checks.
5. Merge unit, API, and manual results into the final XLSX and assignment report.

